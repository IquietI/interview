<?php
/**
 * Created by PhpStorm.
 * User: LuCiF3R
 * Date: 8/8/2021
 * Time: 5:05 PM
 */
function index(){

}