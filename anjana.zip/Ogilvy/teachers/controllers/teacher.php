<?php
/**
 * Created by PhpStorm.
 * User: LuCiF3R
 * Date: 8/9/2021
 * Time: 11:04 AM
 */
require "../../configs/Db_connection.php";
class teacher
{
    function index(){
        http_redirect(get_baseurl()."/teachers/views/Teacher_view.php");
    }

}